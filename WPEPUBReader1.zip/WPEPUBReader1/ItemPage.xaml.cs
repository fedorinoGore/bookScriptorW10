﻿using WPEPUBReader1.Common;
using WPEPUBReader1.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Input;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using VersFx.Formats.Text.Epub;
using Windows.Storage;
using System.Diagnostics;
using Windows.UI.Xaml.Media.Imaging;
using VersFx.Formats.Text.Epub.Entities;
using VersFx.Formats.Text.Epub.Schema.Opf;
using VersFx.Formats.Text.Epub.Schema.Navigation;
using WPEPUBReader1.WebView;
using Windows.Storage.Streams;
using Windows.UI.ViewManagement;
using System.Threading.Tasks;
using System.Collections.ObjectModel;


// The Hub Application template is documented at http://go.microsoft.com/fwlink/?LinkID=391641

namespace WPEPUBReader1
{
    /// <summary>
    /// A page that displays details for a single item within a group.
    /// </summary>
    /// TO-DO: Current class is not SOLID. Have to split on few classes.
    /// Or more likely just get rid of this class to make all manipulations in memmory without opening or creating files.
    public sealed class IndexFileMonocleGenerator
    {
        private StorageFolder _workingFolder;
        private string _templateName;
        private string _indexName;
        private string _templateContent;
        private StorageFile _indexFile, _templateFile;
        private bool _sucess;

        public StorageFile IndexFile { get { return _indexFile; } }
        public string TemplateFileContent { get { return _templateContent; } }
        

        public async Task InitializeFiles()
        {

            //try
            //{
            //    //_templateFile = await _workingFolder.GetFileAsync(_templateName);
            //    Uri uri = new Uri("ms-appx:///html/template.html");
            //    Uri uri1 = new Uri("ms-appdata:///html/template.html");
            //    _templateFile = await StorageFile.GetFileFromApplicationUriAsync(uri1);
            //    _templateContent = await Windows.Storage.FileIO.ReadTextAsync(_templateFile);
            //}
            //catch (Exception)
            //{

            //    _sucess = false;
            //}
            try
            {
                //_indexFile = await _workingFolder.CreateFileAsync(_indexName, CreationCollisionOption.ReplaceExisting);
                _indexFile = await ApplicationData.Current.LocalFolder.CreateFileAsync(_indexName, CreationCollisionOption.ReplaceExisting);
            }
            catch (Exception)
            {

                _sucess = false;
            }
            _sucess = true;

        }

        public bool FilesAreOk()
        {
            return _sucess;
        }

        public IndexFileMonocleGenerator(StorageFolder folder)
        {
            _workingFolder = folder;
            _indexFile = null;
            _templateFile = null;
            _templateName = "index-template.html";
            _indexName = "index.html";
            _sucess = false;
            _templateContent = "<!DOCTYPE html><html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\">" +
                "<head>\n<title> Book title maybe?</title>\n<meta charset = \"utf-8\"/>\n" +
                "<script src=\"Script/monocore.js\">\n</script><link rel=\"stylesheet\" type=\"text/css\" href=\"css/monocore.css\"/>\n" +
                "<!--Here the magic starts-->\n" +
                "<script type=\"text/javascript\">\n" +
                "var bookData = {\n" +
                  "getComponents:" +
                  "getContents:" +
                  "getComponent: function(componentId) {" +
                    "return { url: componentId};},\n" +
                  "getMetaData: function(key) {" +
                    "return  {title: \"Test document\", creator:\"Aron Woost\"}[key];\n" +
                   "}\n" +
                 "}\n" +
                "Monocle.Events.listen(window, 'load', function(){ window.reader = Monocle.Reader('reader', bookData);});\n" +
                "</script>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div id = \"reader\" style=\"width:350px; height:500px;\">\nTest drive 522 chapters\n</div>\n" +
                "</body>\n" +
                "</html>";
           
        }
    }

    //To-DO создать класс или объект типа singleton с глобальной областью видимости  с данными текущей открытой книги
    public static class CurrentBook
    {
        private static EpubBook __currentBook = new EpubBook();
        private static StorageFolder __booksFolder = null;


        public static async Task<StorageFolder> GetBookFolder(string path = "Books")
        {
            try
            {
                __booksFolder = await Windows.ApplicationModel.Package.Current.InstalledLocation.CreateFolderAsync(path, CreationCollisionOption.OpenIfExists);
            }
            catch (Exception)
            {

                throw new Exception("/Books/ Folder cannot be opened or created");
            }
            return __booksFolder;
        }

        public static EpubBook CurrentEpubBook
        {
            get { return __currentBook; }
        }

        public static async Task<bool> SetCurentBookContent(string fileName)
        {
            __currentBook = await EpubReader.OpenBookAsync("fileName");
            if (__currentBook != null)
            {
                return true;
            }
            return false;
        }
    }

    public sealed partial class ItemPage : Page
    {
        private readonly NavigationHelper navigationHelper;
        private readonly ObservableDictionary defaultViewModel = new ObservableDictionary();
        public static EpubBook currentEpubBook = new EpubBook();

        StatusBarProgressIndicator progressbar = StatusBar.GetForCurrentView().ProgressIndicator;

        private StreamUriWinRTResolver myStorageResolver;
        private MemoryStreamUriWinRTResolver myMemoryResolver;

        public ItemPage()
        {
            myStorageResolver = new StreamUriWinRTResolver();
            myMemoryResolver = new MemoryStreamUriWinRTResolver();
            this.InitializeComponent();

            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += this.NavigationHelper_LoadState;
            this.navigationHelper.SaveState += this.NavigationHelper_SaveState;
        }

        /// <summary>
        /// Gets the <see cref="NavigationHelper"/> associated with this <see cref="Page"/>.
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        /// <summary>
        /// Gets the view model for this <see cref="Page"/>.
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        public static void ShowLoadingProgress(double progress)
        {
            var frame = (Frame)Window.Current.Content;
            var page = (ItemPage)frame.Content;
            page.bookLoadingProgressBar.Value = progress;
        }


        /// <summary>
        /// Populates the page with content passed during navigation. Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>.
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private async void NavigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
            // TODO: Create an appropriate data model for your problem domain to replace the sample data
            var item = await SampleDataSource.GetItemAsync((string)e.NavigationParameter);
            this.DefaultViewModel["Item"] = item;
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/>.</param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void NavigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
            // TODO: Save the unique state of the page here.
        }

        #region NavigationHelper registration

        /// <summary>
        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// <para>
        /// Page specific logic should be placed in event handlers for the
        /// <see cref="NavigationHelper.LoadState"/>
        /// and <see cref="NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method
        /// in addition to page state preserved during an earlier session.
        /// </para>
        /// </summary>
        /// <param name="e">Provides data for navigation methods and event
        /// handlers that cannot cancel the navigation request.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            this.navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private async void CreateIndexforMonocleAsync()
        {
            //same as (ms-appx://HTML/index.html)
            var _htmlFolder = Windows.ApplicationModel.Package.Current.InstalledLocation;
            _htmlFolder = await _htmlFolder.GetFolderAsync("HTML");
            
             IndexFileMonocleGenerator _generator = new IndexFileMonocleGenerator(_htmlFolder);
            await _generator.InitializeFiles();

            if (!_generator.FilesAreOk())
            {
                throw new Exception(string.Format("template.html not found in /HTML/ folder or index.html cannot be created"));
            }

            //reading content to string
            var _indexFileContent = _generator.TemplateFileContent;

            string componentsTagString = "getComponents:";
            string contentsTagString = "getContents:";
            int indexOfComponentsTag = _indexFileContent.IndexOf(componentsTagString);
            int lengthOfComponentsTag = componentsTagString.Length;

            string componentInjectonPrefix = " function() {\nreturn [";
            string componentInjectonPostfix = "];\n},\n";
            string allComponents = BuildAllXHTMLFilesToString();
            //Injecting after the <head>        
            _indexFileContent = _indexFileContent.Insert(indexOfComponentsTag + lengthOfComponentsTag,
                componentInjectonPrefix+allComponents+componentInjectonPostfix);

            int indexOfContentTag = _indexFileContent.IndexOf(contentsTagString);
            string allContent = BuildContentToString();
            _indexFileContent = _indexFileContent.Insert(indexOfContentTag + contentsTagString.Length,
                componentInjectonPrefix + allContent + componentInjectonPostfix);
            await FileIO.WriteTextAsync(_generator.IndexFile, _indexFileContent);
            //Adding a new item to the HTML list of book files
            EpubTextContentFile _indexMemoryItem = new EpubTextContentFile()
            {
                Content = _indexFileContent,
                FileName = "index.html",
                ContentType = EpubContentType.XHTML_1_1,
                ContentMimeType = "text/html"
            };
            currentEpubBook.Content.Html.Add("index.html",_indexMemoryItem);
            Debug.WriteLine(string.Format("-------- Here comes the final result:------- \n{0}\n ------------------------------", _indexFileContent));

        }

        private string BuildContentToString()
        {
            string _result = string.Empty;
            foreach (EpubChapter chapter in currentEpubBook.Chapters)
            {
                // Title of chapter
                _result += "{";
                _result += "title: \"" +chapter.Title+"\", src: '"+chapter.ContentFileName+"'";
                // Nested chapters
                if (chapter.SubChapters.Any())
                {
                    _result += "\n,children: [";
                    foreach (EpubChapter subChapter in chapter.SubChapters)
                    {
                        _result += "\n{title: \"" + subChapter.Title + "\", src: '" + subChapter.ContentFileName + "'},";

                    }
                    _result = _result.Remove(_result.Length - 1);
                    _result += "]\n";
                }
                _result += "},";
            }
            _result = _result.Remove(_result.Length - 1);
            return _result;
        }

        private string BuildAllXHTMLFilesToString()
        {
            string _result = string.Empty;
            _result = "'"+string.Join("', '", currentEpubBook.Content.Html.Keys)+"'";

            return _result;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            //Init epub object. 

            //bool fileExist = await EpubReader.DoesFileExistAsync(Windows.ApplicationModel.Package.Current.InstalledLocation, "test.epub");
            //if (!fileExist)
            //    throw new Exception(string.Format("File test.epub not found, bitch"));

            progressbar.Text = "Загрузка книги";
            await progressbar.ShowAsync();
            //bookLoadingProgressBar.Visibility = Visibility.Visible;

            // Opening a book
            currentEpubBook = await EpubReader.OpenBookAsync("test.epub");

            if (currentEpubBook != null)
            {
                loadEbookButton.Content = "Loaded";
                loadEbookButton.IsEnabled = false;
            }
            //// COMMON PROPERTIES
            //// Book's title
            //string title = currentEpubBook.Title;
            //// Book's authors (comma separated list)
            //string author = currentEpubBook.Author;
            //// Book's authors (list of authors names)
            //List<string> authors = currentEpubBook.AuthorList;
            //// Book's cover image (null if there are no cover)
            //BitmapImage coverImage = currentEpubBook.CoverImage;
            //// ShowCoverImage(coverImage); //Only for testing purposes

            

            // CONTENT

            // Book's content (HTML files, stlylesheets, images, fonts, etc.)
            EpubContent bookContent = currentEpubBook.Content;


            // IMAGES

            // All images in the book (file name is the key)
            //Dictionary<string, EpubByteContentFile> images = bookContent.Images;

            //EpubByteContentFile firstImage = images.Values.First();

            //// Content type (e.g. EpubContentType.IMAGE_JPEG, EpubContentType.IMAGE_PNG)
            //EpubContentType contentType = firstImage.ContentType;

            //// MIME type (e.g. "image/jpeg", "image/png")
            //string mimeContentType = firstImage.ContentMimeType;

            //// Creating Image class instance from content
            ////using (MemoryStream imageStream = new MemoryStream(firstImage.Content))
            ////{
            ////    Image image = Image.FromStream(imageStream);
            ////}


            // HTML & CSS

            // All XHTML files in the book (file name is the key)
            Dictionary<string, EpubTextContentFile> htmlFiles = bookContent.Html;

            // All CSS files in the book (file name is the key)
            Dictionary<string, EpubTextContentFile> cssFiles = bookContent.Css;

            

            // All CSS content in the book
            //foreach (EpubTextContentFile cssFile in cssFiles.Values)
            //{
            //    string cssContent = cssFile.Content;
            //}
            // OTHER CONTENT

            // All fonts in the book (file name is the key)
            // Dictionary<string, EpubByteContentFile> fonts = bookContent.Fonts;

            // All files in the book (including HTML, CSS, images, fonts, and other types of files)
            Dictionary<string, EpubContentFile> allFiles = bookContent.AllFiles;

            //To-DO:
            //Определить первый файл в книге - через spine или через guide
            //Отслеживать клики по экрану и по краям экрана - чтобы листать вперед и назад.
            //Отслеживать, когда на экране последняя column из файла и нужно подгружать следующую
            //------------------------------------- Итак: ---------------------------------------------------------------------------------
            //-----------------------------------------------------------------------------------------------------------------------------
            // --- Делаем инъекцию JavaScripta с моноклем -----------------------
            progressbar.Text = "Форматирование";
            // Entire HTML content of the book should be injected in case we are showing chapter by chapter, and not pretending to load the whole set of chapters
            //foreach (KeyValuePair<string, EpubTextContentFile> htmlItem in htmlFiles)
            //{
            //    string injectedItem = WebViewHelpers.injectMonocle(htmlItem.Value.Content,
            //   (int)bookReaderWebViewControl.ActualWidth, (int)bookReaderWebViewControl.ActualHeight);
            //    htmlItem.Value.Content = injectedItem;
            //}


            // --- Организуем навигацию из потока --------------------

            //Uri url = bookReaderWebViewControl.BuildLocalStreamUri("MemoryTag", "section4.xhtml");
            Uri url = bookReaderWebViewControl.BuildLocalStreamUri("MemoryTag", "index.html");
            bookReaderWebViewControl.NavigateToLocalStreamUri(url, myMemoryResolver);

            await progressbar.HideAsync();

            //Now we could have a look at the chapters list
            chaptersMenuButton.IsEnabled = true;
            //bookLoadingProgressBar.Visibility = Visibility.Collapsed;

            // ACCESSING RAW SCHEMA INFORMATION

            //// EPUB OPF data
            //EpubPackage package = epubBook.Schema.Package;

            //// Enumerating book's contributors
            //foreach (EpubMetadataContributor contributor in package.Metadata.Contributors)
            //{
            //    string contributorName = contributor.Contributor;
            //    string contributorRole = contributor.Role;
            //}

            //// EPUB NCX data
            //EpubNavigation navigation = epubBook.Schema.Navigation;

            //// Enumerating NCX metadata
            //foreach (EpubNavigationHeadMeta meta in navigation.Head)
            //{
            //    string metadataItemName = meta.Name;
            //    string metadataItemContent = meta.Content;
            //}

        }

        private void ShowCoverImage(BitmapImage coverImage)
        {
            Image coverImageControl = new Image() { Width = 320, Height = 480, Stretch = Stretch.Uniform };
            coverImageControl.Source = coverImage;
            ContentRoot.Children.Add(coverImageControl);
        }

        private void CommandBar_Opened(object sender, object e)
        {

        }

        private void chaptersMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // CHAPTERS
            // Enumerating chapters
            chaptersMenuButton.IsEnabled = false;
            ObservableCollection<EpubChapter> fullListOfChapters = new ObservableCollection<EpubChapter>();

            foreach (EpubChapter chapter in currentEpubBook.Chapters)
            {
                // Title of chapter
                // string chapterTitle = chapter.Title;

                // HTML content of current chapter
                //string chapterHtmlContent = chapter.HtmlContent;
                fullListOfChapters.Add(chapter);
                // Nested chapters
                foreach (EpubChapter subChapter in chapter.SubChapters)
                {
                    subChapter.Title = "    " + subChapter.Title;
                    fullListOfChapters.Add(subChapter);
                }
                //List<EpubChapter> subChapters = chapter.SubChapters;
            }
            ChaptersList.ItemsSource = fullListOfChapters;
            // open the Popup if it isn't open already 
            if (!StandartPopup.IsOpen) { StandartPopup.IsOpen = true; }
        }

        private void ClosePopupClicked(object sender, RoutedEventArgs e)
        {
            // if the Popup is open, then close it 
            if (StandartPopup.IsOpen) { StandartPopup.IsOpen = false; }
            chaptersMenuButton.IsEnabled = true;
        }

        private void Test_Click(object sender, RoutedEventArgs e)
        {
            CreateIndexforMonocleAsync();
        }
    }
}
