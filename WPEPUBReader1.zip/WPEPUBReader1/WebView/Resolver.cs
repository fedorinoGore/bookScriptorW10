﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.Web;

namespace WPEPUBReader1.WebView
{
    public sealed class StreamUriWinRTResolver : IUriToStreamResolver
    {
        /// <summary>
        /// The entry point for resolving a Uri to a stream.
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public IAsyncOperation<IInputStream> UriToStreamAsync(Uri uri)
        {
            if (uri == null)
            {
                throw new Exception();
            }
            string path = uri.AbsolutePath;

            if (System.Diagnostics.Debugger.IsAttached)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("Stream Requested: {0}", uri.ToString()));
            }

            // Because of the signature of the this method, it can't use await, so we 
            // call into a seperate helper method that can use the C# await pattern.
            return getContent(path).AsAsyncOperation();
        }

        /// <summary>
        /// Helper that cracks the path and resolves the Uri
        /// Uses the C# await pattern to coordinate async operations
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private async Task<IInputStream> getContent(string path)
        {
            // We use a package folder as the source, but the same principle should apply
            // when supplying content from other locations
            StorageFolder current = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFolderAsync("html");
            //string fileExtension = Path.GetExtension(path);

            // Trim the initial '/' if applicable
            if (path.StartsWith("/")) path = path.Remove(0, 1);
            // Split the path into an array of nodes
            string[] nodes = path.Split('/');

            // Walk the nodes of the path checking against the filesystem along the way
            for (int i = 0; i < nodes.Length; i++)
            {
                try
                {
                    // Try and get the node from the file system
                    IStorageItem item = await current.GetItemAsync(nodes[i]);

                    if (item.IsOfType(StorageItemTypes.Folder) && i < nodes.Length - 1)
                    {
                        // If the item is a folder and isn't the leaf node
                        current = item as StorageFolder;
                    }
                    else if (item.IsOfType(StorageItemTypes.File) && i == nodes.Length - 1)
                    {
                        // If the item is a file and is the leaf node
                        
                        //if ((nodes[i] == "monocore.css") || (nodes[i] == "monocore.js"))
                        //{
                            StorageFile f = item as StorageFile;
                            IRandomAccessStream stream = await f.OpenAsync(FileAccessMode.Read);
                            return stream;
                        //}
                        //else //Any other file than locally hosted monocleJS
                        //{
                        //    //TO-DO - check if item exist i the dictionary
                        //    string content = ItemPage.currentEpubBook.Content.Html[nodes[i]].Content;
                        //    using (InMemoryRandomAccessStream ms = new InMemoryRandomAccessStream())
                        //    {
                        //        using (DataWriter writer = new DataWriter(ms.GetOutputStreamAt(0)))
                        //        {
                        //            writer.WriteBytes(Encoding.UTF8.GetBytes(content ?? ""));
                        //            await writer.StoreAsync();
                        //            return ms;
                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        return null;
                        //Leaf is not a file, or the file isn't the leaf node in the path
                        throw new Exception("Invalid path");
                    }
                }
                catch (Exception) { throw new Exception("Invalid path"); }
            }
            return null;
        }
    }

    public sealed class MemoryStreamUriWinRTResolver : IUriToStreamResolver
    {
        /// <summary>
        /// The entry point for resolving a Uri to a stream.
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public IAsyncOperation<IInputStream> UriToStreamAsync(Uri uri)
        {
            if (uri == null)
            {
                throw new Exception();
            }
            string path = uri.AbsolutePath;

            if (System.Diagnostics.Debugger.IsAttached)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("Stream Requested: {0}", uri.ToString()));
            }

            // Because of the signature of the this method, it can't use await, so we 
            // call into a seperate helper method that can use the C# await pattern.
            return getContent(path).AsAsyncOperation();
        }

        /// <summary>
        /// Helper that cracks the path and resolves the Uri
        /// Uses the C# await pattern to coordinate async operations
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private async Task<IInputStream> getContent(string path)
        {
            // We use a package folder as the source, but the same principle should apply
            // when supplying content from other locations
            StorageFolder current = await Windows.ApplicationModel.Package.Current.InstalledLocation.GetFolderAsync("html");
            string fileExtension = Path.GetExtension(path).ToLowerInvariant();
            
            // Trim the initial '/' if applicable
            if (path.StartsWith("/")) path = path.Remove(0, 1);
            // Split the path into an array of nodes
            string[] nodes = path.Split('/');

            // Walk the nodes of the path checking against the filesystem along the way
            for (int i = 0; i < nodes.Length; i++)
            {
                try
                {
                    // Try and get the node from the file system
                    IStorageItem item = await current.GetItemAsync(nodes[i]);

                    if (item.IsOfType(StorageItemTypes.Folder) && i < nodes.Length - 1)
                    {
                        // If the item is a folder and isn't the leaf node
                        current = item as StorageFolder;
                    }
                    else if (item.IsOfType(StorageItemTypes.File) && i == nodes.Length - 1)
                    {
                        // If the item is a file and is the leaf node
                        // -----------------
                        if ((nodes[i] == "monocore.css") || (nodes[i] == "monocore.js") || (nodes[i] == "index.html"))
                        {
                            StorageFile f = item as StorageFile;
                            IRandomAccessStream stream = await f.OpenAsync(FileAccessMode.Read);
                            return stream;
                        }
                        else //Any other file than locally hosted
                        {
                            //TO-DO - check if item exist in the dictionary before any others actions
                            string content = string.Empty;
                            switch (fileExtension)
                            {
                                case ".xhtml":
                                    //return GetContentAsStreamFromEPUB(nodes[i]);
                                    content = ItemPage.currentEpubBook.Content.Html[path].Content;
                                    InMemoryRandomAccessStream ms = new InMemoryRandomAccessStream();
                                    using (DataWriter writer = new DataWriter(ms.GetOutputStreamAt(0)))
                                    {
                                        writer.WriteBytes(Encoding.UTF8.GetBytes(content ?? ""));
                                        await writer.StoreAsync();
                                        return ms;
                                    }
                                case ".css":
                                    content = ItemPage.currentEpubBook.Content.Css[path].Content;
                                    ms = new InMemoryRandomAccessStream();
                                        using (DataWriter writer = new DataWriter(ms.GetOutputStreamAt(0)))
                                        {
                                            writer.WriteBytes(Encoding.UTF8.GetBytes(content ?? ""));
                                            await writer.StoreAsync();
                                            return ms;
                                        }
                                case ".png":
                                case ".jpg":
                                case ".jpeg":
                                case ".bmp":
                                case ".svg":
                                case ".gif":
                                    byte[] byteContent = ItemPage.currentEpubBook.Content.Images[path].Content;
                                    ms = new InMemoryRandomAccessStream();
                                    using (DataWriter writer = new DataWriter(ms.GetOutputStreamAt(0)))
                                    {
                                        writer.WriteBytes((byte[])byteContent);
                                        await writer.StoreAsync();
                                        return ms;
                                    }
                                    break;
                                case ".js":
                                    return null;
                            }
                        }
                       // return null;
                    }
                    else
                    {
                        return null;
                        //Leaf is not a file, or the file isn't the leaf node in the path
                        throw new Exception("Invalid path");
                    }
                }
                catch (Exception) { throw new Exception("Invalid path"); }
            }
            return null;
        }

        private async Task<IInputStream> GetContentAsStreamFromEPUB(string itemName)
        {
            byte[] content = ItemPage.currentEpubBook.Content.AllFiles[itemName].Content;
            using (InMemoryRandomAccessStream ms = new InMemoryRandomAccessStream())
            {
                using (DataWriter writer = new DataWriter(ms.GetOutputStreamAt(0)))
                {
                    writer.WriteBytes((byte[])content);
                    await writer.StoreAsync();
                    return ms;
                }
            }
            return null;
        }
    }
}
