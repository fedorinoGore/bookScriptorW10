﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VersFx.Formats.Text.Epub.Schema.Opf
{
    public class EpubMetadataContributor
    {
        public string Contributor { get; set; }
        public string FileAs { get; set; }
        public string Role { get; set; }
    }
}
